import {Stack} from 'expo-router';import {StatusBar} from 'expo-status-bar';import {AppProvider} from '@/src/store/app';
export default function Layout(){return <AppProvider><StatusBar style="light"/><Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:'#070610'}}}/></AppProvider>}
