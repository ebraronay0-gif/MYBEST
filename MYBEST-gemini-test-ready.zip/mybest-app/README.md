# MYBEST — Your AI Best Friend

Global-first Expo/React Native app foundation with automatic device-language detection, localized character names, dark premium UI, chat, character selection, memory, tools, settings and legal screens.

## Stack
- Expo SDK 57 / React Native 0.86
- Expo Router
- TypeScript
- AsyncStorage for local MVP state
- Server-side AI integration boundary

Expo Router is the recommended navigation approach for current Expo projects. See the official docs: https://docs.expo.dev/router/introduction/

## Run
```bash
npm install
npx expo start
```

For Android:
```bash
npx expo start --android
```

## AI backend
For the easiest Android test, open `server/API_KEY.txt` and replace its single line with your Gemini API key. Do not add quotes or spaces. This file is ignored by Git. For production, use a server environment variable instead.

Copy `.env.example` to `.env` when using environment variables and set `EXPO_PUBLIC_API_URL` in the mobile app to the deployed API.

The included `server/` is only a safe integration skeleton. Before production, connect a real AI provider server-side, add authentication, rate limiting, abuse prevention, moderation/reporting, observability, encrypted storage, backups and subscription verification.

## Production legal checklist
The in-app Terms, Privacy Policy and Community Guidelines are starter product documents, **not legal advice**. Before store submission, replace them with documents reviewed for the operator's country, target markets, GDPR/UK GDPR/CCPA as applicable, children's privacy, subscription rules, data retention/deletion, international transfers and processor disclosures.

## Store readiness still required
- Apple/Google developer accounts
- Final company/legal entity and support email/address
- App icon and splash assets in required sizes
- Privacy/Data Safety declarations
- Subscription products configured in App Store Connect / Play Console
- Backend AI provider and production database
- Account deletion endpoint and in-app flow
- AI output reporting/blocking and moderation
- Crash/error monitoring
- EAS credentials and store signing

## Important
The app intentionally does not ship an AI-provider secret. Do not put Gemini/OpenAI keys into `EXPO_PUBLIC_*` variables or mobile code.
