export const colors = {
  bg: '#070610', panel: '#111020', panel2: '#17152a', text: '#F7F4FF', muted: '#AAA5BC', purple: '#A43BFF', pink: '#F24DDB', border: '#2A2640', green: '#51D88A', red: '#FF5C70', gold: '#FFC857'
};
export const radius = { sm: 12, md: 18, lg: 26 };
